﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagement
{
    class Book
    {
        // display BookEnter Form
        private string _title;
        private string _authorFirstName;
        private string _authorLastName;
        private string _summary;
        private string _publisher;
        private Int32 _isbn;
        //private image _image;


        // on Enter
        // Get typed items and place in SQL database
        // Confirm item is entered




    }
}
