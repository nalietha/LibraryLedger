﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagement.Classes
{
    class Movie : AddMedia
    {
        private string _title;
        private string _directorFirstName;
        private string _directorLastName;
        private string _summary;
        private string _producer;
        
        //private string[] _actors = new Array;




    }
}
